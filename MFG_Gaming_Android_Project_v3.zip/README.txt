MFG Gaming Android project - expanded prototype

Included:
- Android WebView app wrapper and Android Studio Gradle project
- MFG Gaming tournament home screen
- Solo, Duo, Squad tournament cards
- Subscribe prompt with link to https://youtube.com/@mfggaming99
- Self-confirmation step before free registration
- Registration form (local device storage only)
- Room ID/password display
- Local Admin panel with PIN gate, tournament status, schedule, prize text, room ID/password and result fields
- Go To Live / YouTube channel button

IMPORTANT: This is still a FRONT-END PROTOTYPE, not a production-ready multi-user tournament platform.
The app cannot automatically verify YouTube subscriptions. The admin PIN and data are stored locally on one device and are not secure enough for public production use. Registrations, room updates, player counts and results do NOT sync across phones.
For a real launch, connect Firebase or another secure backend, implement authenticated admin access and server-side data rules, test on Android devices, add a privacy policy, and build/sign the APK in Android Studio. This environment does not have Android SDK/Gradle installed, so it cannot output a compiled APK.
Build: Open folder in Android Studio > Sync Gradle > Build > Build APK(s).
